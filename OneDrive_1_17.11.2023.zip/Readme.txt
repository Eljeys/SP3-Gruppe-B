Verdens 100 bedste film (iflg. én imdb-liste) er gemt i filen film.txt. De står på hver sin linje i formatet: titel; årstal; kategori1, kategori2, ..; rating
Kategorierne er: Crime, Drama, Biography, Sport, History, Romance, War, Mystery, Adventure, Family, Fantasy, Thriller, Horror, Film-Noir, Action, Sci-fi, Comedy , Musical, Western og Music.

Hvis I vil lave grafisk brugergrænseflade, kan I bruge de tilhørende filmplakater, som ligger i filen filmplakater.zip. De enkelte billeder er navngivet efter filmen.  
Billederne kan være (og er sikkert) beskyttet af copyright, så lad dem blive indenfor vores lukkede kreds :-)

Verdens 100 bedste serier (igen iflg. en anden imdb-liste) er gemt i filen serier.txt. De står på hver sin linje i formatet: titel; årtalFra-årstalTil; kategori1, kategori2, ..; rating; sæsonnummer-antalEpisoder, sæsonnummer-antalEpisoder...; 
Hvis serien stadig kører (eller gjorde det, da listen blev lavet) er der et årstalFra og en bindestreg, men intet årstalTil. Hvis serien kun kørte i ét år, er der et årstalFra, men ingen bindestreg. 
Kategorierne er: Talk-show, Documentary, Crime, Drama, Action, Adventure, Drama, Comedy, Fantasy, Animation, Horror, Sci-fi, War, Thriller, Mystery, Biography, History, Family, Western, Romance og Sport.

Tilhørende billeder ligger i filen serieforsider.zip. De enkelte billeder er navngivet efter serien.  
Billederne kan være (og er sikkert) beskyttet af copyright, så lad dem blive indenfor vores lukkede kreds :-)